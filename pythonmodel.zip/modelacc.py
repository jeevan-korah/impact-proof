"""
Model Accuracy Comparison Script
Compares old vs new model performance across classification, regression, or ranking tasks.

Usage:
    python model_comparison.py --config config.yaml
    python model_comparison.py --old_model old.pkl --new_model new.pkl --test_data test.csv --task classification
"""

import argparse
import json
import logging
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import joblib
import yaml
from sklearn.metrics import (
    # Classification
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    classification_report,
    confusion_matrix,
    # Regression
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_model(path: str) -> Any:
    """Load a serialised model (joblib / pickle)."""
    log.info("Loading model: %s", path)
    return joblib.load(path)


def load_dataset(path: str, label_col: str = "label") -> tuple[pd.DataFrame, pd.Series]:
    """
    Load a CSV / JSON / Parquet test dataset.
    Returns (features_df, labels_series).
    """
    p = Path(path)
    if p.suffix == ".csv":
        df = pd.read_csv(p)
    elif p.suffix == ".json":
        df = pd.read_json(p)
    elif p.suffix in (".parquet", ".pq"):
        df = pd.read_parquet(p)
    else:
        raise ValueError(f"Unsupported file format: {p.suffix}")

    if label_col not in df.columns:
        raise ValueError(
            f"Label column '{label_col}' not found. "
            f"Available columns: {list(df.columns)}"
        )

    y = df[label_col]
    X = df.drop(columns=[label_col])
    log.info("Dataset loaded — %d rows, %d features", len(df), X.shape[1])
    return X, y


def timed_predict(model, X: pd.DataFrame) -> tuple[np.ndarray, float]:
    """Return predictions and wall-clock inference time (seconds)."""
    start = time.perf_counter()
    preds = model.predict(X)
    elapsed = time.perf_counter() - start
    return preds, elapsed


# ── Metrics ──────────────────────────────────────────────────────────────────

def classification_metrics(y_true, y_pred, model, X, average: str = "weighted") -> dict:
    metrics = {
        "accuracy":  accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, average=average, zero_division=0),
        "recall":    recall_score(y_true, y_pred, average=average, zero_division=0),
        "f1":        f1_score(y_true, y_pred, average=average, zero_division=0),
    }
    # AUC-ROC — only if model supports probability output
    try:
        proba = model.predict_proba(X)
        classes = np.unique(y_true)
        if len(classes) == 2:
            metrics["roc_auc"] = roc_auc_score(y_true, proba[:, 1])
        else:
            metrics["roc_auc"] = roc_auc_score(
                y_true, proba, multi_class="ovr", average=average
            )
    except AttributeError:
        log.warning("Model does not support predict_proba — skipping ROC-AUC.")
    return metrics


def regression_metrics(y_true, y_pred) -> dict:
    mse = mean_squared_error(y_true, y_pred)
    return {
        "mae":  mean_absolute_error(y_true, y_pred),
        "mse":  mse,
        "rmse": np.sqrt(mse),
        "r2":   r2_score(y_true, y_pred),
    }


# ── Reporting ─────────────────────────────────────────────────────────────────

def delta(new_val: float, old_val: float) -> str:
    """Pretty-print absolute and relative change."""
    abs_d = new_val - old_val
    rel_d = (abs_d / old_val * 100) if old_val != 0 else float("nan")
    sign = "+" if abs_d >= 0 else ""
    return f"{sign}{abs_d:.4f}  ({sign}{rel_d:.2f}%)"


def print_comparison(old_metrics: dict, new_metrics: dict, inference: dict) -> None:
    all_keys = sorted(set(old_metrics) | set(new_metrics))
    col_w = 14

    header = f"{'Metric':<20} {'Old Model':>{col_w}} {'New Model':>{col_w}} {'Delta':>24}"
    sep    = "-" * len(header)
    print("\n" + sep)
    print("  MODEL COMPARISON REPORT")
    print(sep)
    print(header)
    print(sep)

    for k in all_keys:
        old_v = old_metrics.get(k, float("nan"))
        new_v = new_metrics.get(k, float("nan"))
        d     = delta(new_v, old_v) if not np.isnan(old_v) else "N/A"
        print(f"  {k:<18} {old_v:>{col_w}.4f} {new_v:>{col_w}.4f} {d:>24}")

    print(sep)
    print(f"  {'Inference time':<18} {inference['old']:>{col_w}.4f}s {inference['new']:>{col_w}.4f}s")
    print(sep)

    # Pick the best available metric to summarise improvement
    primary = next(
        (m for m in ["f1", "roc_auc", "accuracy", "r2"] if m in new_metrics),
        list(new_metrics.keys())[0]
    )
    old_v = old_metrics[primary]
    new_v = new_metrics[primary]
    abs_d = new_v - old_v
    rel_d = (abs_d / old_v * 100) if old_v != 0 else 0

    if abs_d > 0:
        summary = (
            f"  ✅ The new model improved by {abs_d:.4f} ({rel_d:.2f}%) "
            f"over the old model on {primary}."
        )
    elif abs_d < 0:
        summary = (
            f"  ❌ The new model is worse by {abs(abs_d):.4f} ({abs(rel_d):.2f}%) "
            f"compared to the old model on {primary}."
        )
    else:
        summary = f"  ➡️  The new model shows no change in {primary} compared to the old model."

    print(summary)
    print(sep + "\n")


def save_results(results: dict, output_path: str) -> None:
    Path(output_path).write_text(json.dumps(results, indent=2))
    log.info("Results saved to %s", output_path)


# ── Main ──────────────────────────────────────────────────────────────────────

def run_comparison(cfg: dict) -> dict:
    task        = cfg.get("task", "classification").lower()
    label_col   = cfg.get("label_column", "label")
    average     = cfg.get("average", "weighted")   # for multi-class classification
    output_file = cfg.get("output", "comparison_results.json")

    # Load data
    X, y = load_dataset(cfg["test_data"], label_col=label_col)

    # Load models
    old_model = load_model(cfg["old_model"])
    new_model = load_model(cfg["new_model"])

    # Predict
    old_preds, old_time = timed_predict(old_model, X)
    new_preds, new_time = timed_predict(new_model, X)

    # Compute metrics
    if task == "classification":
        old_metrics = classification_metrics(y, old_preds, old_model, X, average)
        new_metrics = classification_metrics(y, new_preds, new_model, X, average)

        log.info("\n--- Old Model Classification Report ---\n%s",
                 classification_report(y, old_preds, zero_division=0))
        log.info("\n--- New Model Classification Report ---\n%s",
                 classification_report(y, new_preds, zero_division=0))

    elif task == "regression":
        old_metrics = regression_metrics(y, old_preds)
        new_metrics = regression_metrics(y, new_preds)
    else:
        raise ValueError(f"Unsupported task: '{task}'. Choose 'classification' or 'regression'.")

    inference = {"old": old_time, "new": new_time}
    print_comparison(old_metrics, new_metrics, inference)

    results = {
        "task": task,
        "n_samples": len(y),
        "old_model": {"path": cfg["old_model"], "metrics": old_metrics, "inference_seconds": old_time},
        "new_model": {"path": cfg["new_model"], "metrics": new_metrics, "inference_seconds": new_time},
    }
    save_results(results, output_file)
    return results


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Compare old vs new model accuracy.")
    p.add_argument("--config",     help="Path to YAML config file")
    p.add_argument("--old_model",  help="Path to old model file")
    p.add_argument("--new_model",  help="Path to new model file")
    p.add_argument("--test_data",  help="Path to test dataset (CSV/JSON/Parquet)")
    p.add_argument("--label_col",  default="label", help="Name of the label/target column")
    p.add_argument("--task",       default="classification", choices=["classification", "regression"])
    p.add_argument("--average",    default="weighted", choices=["micro", "macro", "weighted", "binary"])
    p.add_argument("--output",     default="comparison_results.json", help="Output JSON report path")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    if args.config:
        with open(args.config) as f:
            cfg = yaml.safe_load(f)
    else:
        if not all([args.old_model, args.new_model, args.test_data]):
            raise SystemExit(
                "Provide either --config or all three of --old_model, --new_model, --test_data"
            )
        cfg = {
            "old_model":    args.old_model,
            "new_model":    args.new_model,
            "test_data":    args.test_data,
            "label_column": args.label_col,
            "task":         args.task,
            "average":      args.average,
            "output":       args.output,
        }

    run_comparison(cfg)


if __name__ == "__main__":
    main()
